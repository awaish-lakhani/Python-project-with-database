# User Credentials
host = 'localhost'
user = '--------'
password = '----------'
database = 'contact_management'
